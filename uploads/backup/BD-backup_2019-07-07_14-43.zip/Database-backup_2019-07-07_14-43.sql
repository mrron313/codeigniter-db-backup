#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `age` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `users` (`id`, `name`, `age`, `created_at`) VALUES (1, 'Arif', 21, '2019-07-07');
INSERT INTO `users` (`id`, `name`, `age`, `created_at`) VALUES (2, 'Heme', 23, '2019-07-07');


